# React UI verification

Users, orders, events, prices and inventory are **SIMULATED**. The catalog uses 150 real fragrance references and source-linked product photographs. Checkout does not charge or fulfil an order.

| Check | Required result |
|---|---|
| Native PostgreSQL pytest | All tests pass, including concurrent checkout and real size facets |
| Ruff | Clean |
| Vite production build | Pass |
| Playwright storefront journey | Real image, 150 products, 35 brands, natural search, persistent wishlist/cart, quiz, demo order and consent |
| Playwright protected admin journey | JWT gate, LSTM selection, 12-week horizon, version dialog and all admin panels |
| Playwright mobile journey | No horizontal overflow and usable navigation |

The phase is marked complete and committed only after these checks pass in the native CI run. No new frontend library was added; Playwright replaces the incorrectly configured Vitest command. Recharts was already installed. Local API checks passed for all catalog facets, a 60 ml quiz and reason tags. Local Chromium download was truncated by the execution network, so real browser verification runs on GitHub Actions.

Limits: match percentages are rank alignment, not calibrated purchase probabilities. Approximate 95% bands are not reported as measured coverage. Search labels remain draft and need manual review. Source photographs are not supplier authenticity verification or evidence of distribution rights.
