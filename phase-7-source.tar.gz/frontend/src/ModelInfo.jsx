import { useRef } from "react";

export default function ModelInfo({ version, model = "Discovery models" }) {
  const dialog = useRef(null);
  const date = version ? `${version.slice(0, 4)}-${version.slice(4, 6)}-${version.slice(6, 8)}` : "Unavailable";
  return (
    <>
      <button className="why" onClick={() => dialog.current.showModal()}>About this model</button>
      <dialog ref={dialog} className="model-dialog" aria-labelledby="model-info-title">
        <h2 id="model-info-title">About this model</h2>
        <p><strong>{model}</strong></p>
        <dl><dt>Version</dt><dd>{version || "Unavailable"}</dd><dt>Version date (UTC)</dt><dd>{date}</dd></dl>
        <p className="notice"><strong>SIMULATED DATA</strong><br />Users, orders, events, prices and stock are simulated. Product references and photographs are real catalog sources.</p>
        <p>These models demonstrate a pipeline and methods. Match percentages describe accord alignment, not the probability you will like a fragrance. Search labels still need manual review.</p>
        <p>Forecasts support human review. Four-week backtests do not validate every twelve-week prediction; uncertainty bands are not guarantees.</p>
        <a href="/intelligence">View methods and evaluation</a>
        <form method="dialog"><button className="button">Close model information</button></form>
      </dialog>
    </>
  );
}
